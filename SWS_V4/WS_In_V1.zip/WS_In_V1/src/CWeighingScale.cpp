/* 
  PM_APP.cpp - Application file is used to read the registor values of energy meter ic , calculate the suggested/ required capbank value and also used for detection of 
               power source
            
  Dev: Infiplus Team 
  May 2021  
*/

#include "CWeighingScale.h"

#define SERIAL_DEBUG
#ifdef SERIAL_DEBUG
#define debugPrint(...) Serial.print(__VA_ARGS__)
#define debugPrintln(...) Serial.println(__VA_ARGS__)
#define debugPrintf(...) Serial.printf(__VA_ARGS__)
#define debugPrintlnf(...) Serial.println(F(__VA_ARGS__))
#else
#define debugPrint(...)    //blank line
#define debugPrintln(...)  //blank line
#define debugPrintf(...)   //blank line
#define debugPrintlnf(...) //blank line
#endif

/* Construct */
CWeighingScale::CWeighingScale()
{
  m_bFrameReady = false;
}
/* Destruct */
CWeighingScale::~CWeighingScale(){}

/**************************************************
 * decode incomming data form Scale
 * Input : single char
 * output: result
**************************************************/
uint8_t CWeighingScale::decode(char c)
{
  //debugPrint(c);
  switch(c)
  {
    case '#': // Start Of Frame
      {
        m_frameStared = true;
        isValidFrame = false;
        m_bFrameReady = false;
        rpos = 0;       
      }
      break;
    case '*':
      {
        if(m_frameStared)
        {
          m_frameStared = false;
          m_ReceivedFrame[rpos]= 0;
          isValidFrame = true;
        }
      }
      break;
    default:
      if(rpos < MAX_FARME_SIZE && m_frameStared)
        m_ReceivedFrame[rpos++] = c;
      break;
  }
  if(isValidFrame)
  {
    isValidFrame = false;
    //debugPrintln();
    //debugPrintln(m_ReceivedFrame);
    m_bFrameReady = true;
  }
}
/**************************************************
 * Parse Commands 
 * Input : single char
 * output: result
**************************************************/
uint8_t CWeighingScale::ParseCommnads()
{
  if(m_bFrameReady)
  {
    // debugPrintln("Weight received");
    float Currweight = 0;
    sscanf(m_ReceivedFrame,"%f",&Currweight);
    /*Validate wt Data*/
    if(Currweight <= 300)
    {
        m_fWeight = Currweight;
    }
    else
    {
      return WRONG_FRAME;
    }        
    //debugPrintf("Wt: %f\n",m_fWeight);
    m_bFrameReady = false;
  }
  return VALID_FRAME;
}

/**************************************************
 * Process Send farme to weighing scale
 * Input : sendFrame
 * output: result
**************************************************/
uint8_t CWeighingScale::SendFrame(const char *sendFrame,int repeatCnt)
{ 
  delay(400);
  for(int rep = 0; rep <= repeatCnt; rep++)  
  {
    Serial1.write(sendFrame);
    debugPrintln("sending Frame");
    delay(10);
  }
  return 1;
}