#ifndef CWeighingScale_H
#define CWeighingScale_H

#include "CDeviceConfig.h"
#include "BSP.h"

#define MAX_FARME_SIZE 20

#define UPDATE_FRAME 5
#define REQUSET_FRAME 4
#define OK 0
#define WRONG_FRAME 0
#define VALID_FRAME 1

const char START_FRAME[] = "*!#";
const char STOP_FRAME[] = "*%#";
const char TARE_FRAME[] = "*T#";


class CWeighingScale
{
    private:
        bool isValidFrame;
        bool m_bFrameReady;
        char m_ReceivedFrame[MAX_FARME_SIZE];
        uint8_t rpos;
        bool m_frameStared;

    public:
    /* Construct */
    CWeighingScale();
    /* Destruct */
    ~CWeighingScale();

    float m_ftotalWeight = 0;
    float m_fWeight;
    uint8_t decode(char c);
    uint8_t ParseCommnads();
    uint8_t SendFrame(const char *sendFrame,int repeatCnt = 0);
};

#endif