#include "CDeviceConfig.h"
#include <ArduinoJson.h>

//#define SERIAL_DEBUG
#ifdef SERIAL_DEBUG
#define debugPrint(...) Serial.print(__VA_ARGS__)
#define debugPrintln(...) Serial.println(__VA_ARGS__)
#define debugPrintf(...) Serial.printf(__VA_ARGS__)
#define debugPrintlnf(...) Serial.println(F(__VA_ARGS__))
#else
#define debugPrint(...)    //blank line
#define debugPrintln(...)  //blank line
#define debugPrintf(...)   //blank line
#define debugPrintlnf(...) //blank line
#endif


/*Construct*/
CDeviceConfig::CDeviceConfig()
{
    m_u8IsReboot = 1;
    espResetReason = 0;
    m_tEpoch = 0;
    m_bIsSafeModeOn = false;
    m_u8ReceivedConfigType = NO_CNFG;
}
/*Destruct*/
CDeviceConfig::~CDeviceConfig(){}

/***************************************************************************
*  Safe copy Function to avoid overflow 
****************************************************************************/
static void safeStrcpy(char * destination, const char * source, int sizeofDest)
{
  strncpy(destination,source,sizeofDest-1);
  destination[sizeofDest-1] = 0;
}

/************************************************************
 * Load lotno From File to local Veriables
*************************************************************/
int CDeviceConfig::loadLotno(FILESYSTEM* filesystem)
{
    char rdata[100];
    int ret = 0;
    int Size = filesystem->getFileSize(FNAME_LOTNO);
    if (Size >= 100)
    { 
        debugPrintln("Wrong lotno file size...");
        return 0;
    }
    /*Read File in data streM*/
    ret = filesystem->readFile(FNAME_LOTNO,rdata);
    if(ret > 0)
    {
        StaticJsonDocument<100> Lotno;
        /*De serilaize the file json*/
        DeserializationError err = deserializeJson(Lotno, rdata);
        if (err.code() == DeserializationError::Ok)
        {
            /*Read lotno Version*/
            if(Lotno.containsKey("version"))
            {
                m_dLotnoVer = Lotno["version"];
            }

            /*Read lotno*/
            if(Lotno.containsKey("lotNo"))
            {
                safeStrcpy(m_cLotno,Lotno["lotNo"],sizeof(m_cLotno));
            }
        }
    }
    return 1;
}

/************************************************************
 * Read lotno From File
*************************************************************/
int CDeviceConfig::readLotno(FILESYSTEM* filesystem,char *SiteIdData)
{
  int ret = 0;
  int Size = filesystem->getFileSize(FNAME_LOTNO);
  debugPrintln(Size);
  if (Size >= 100)
  { 
    debugPrintln("Wrong SiteIdList file size...");
    return 0;
  }
  /*Read File in data streM*/
  ret = filesystem->readFile(FNAME_LOTNO,SiteIdData);
  debugPrintln(SiteIdData);
  if(ret > 0)
  {
    return 1;
  }
  return 0;
}