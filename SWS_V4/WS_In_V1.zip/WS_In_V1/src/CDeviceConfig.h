#ifndef DEVICECONFIG_H
#define DEVICECONFIG_H

#include "stdint.h"
#include "esp_system.h"
#include "Ticker.h"
#include "FileSystem.h"

#define FNAME_LOTNO   "/Lotno.txt"

typedef enum
{
    NO_CNFG = 0,
    CNFG_SND
}ConfigFrametype;

class CDeviceConfig
{
    public:
        /*Device Data*/
        char m_cDeviceId[25];
        char m_cSiteId[30];
        char m_cLotno[25];
        char m_cSectionid[20];
        char m_cUserName[25];
        char m_cDeviceName[10];
        uint32_t m_dSiteIdListVer;
        uint32_t m_dLotnoVer;
        uint8_t m_u8IsReboot;
        int espResetReason;
        time_t m_tEpoch;
        bool m_bIsSafeModeOn;
        ConfigFrametype m_u8ReceivedConfigType;

        /*Construct*/
        CDeviceConfig(void);
        /*Destruct*/
        ~CDeviceConfig(void);
        int loadLotno(FILESYSTEM* filesystem);
        int readLotno(FILESYSTEM* filesystem,char *SiteIdData);
};

#endif