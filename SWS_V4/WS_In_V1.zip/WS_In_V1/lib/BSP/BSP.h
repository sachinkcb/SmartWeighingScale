#ifndef BSP_H
#define BSP_H

#include <stdint.h>
#include <string.h>
#include <Wire.h>
#include "time.h"
#include "PCF85063A.h"
#include "MYDISPLAY.h"

#define RELAYON     1
#define RELAYOFF    0

/*LED GPIO PINS DEFINITIONS*/
#define BSP_LED_1    2

/*Button State for detection*/
#define BUTTON_IDLE 0xff
#define BUTTON_1    0
#define BUTTON_2    1
#define BUTTON_3    2
#define BUTTON_4    3
#define BUTTON_5    4

/*BUTTON GPIO PINS DEFINITIONS*/
#define BSP_BTN_1           32  // output_1
#define BSP_BTN_2           33  // output_2
#define BSP_BTN_3           25  // output_3
#define BSP_BTN_4           26  // output_4
#define BSP_BTN_5           36  // input_1   

/*I2C GPIO PINS DEFINITIONS*/
#define BSP_SDA             21
#define BSP_SCL             22


/*Relay  PINS DEFINITIONS*/
//#define BSP_RELAY1         27

/*Hooter Pin*/
#define BSP_HOOTER      4

/*TM1637 4 DIGIT DISPLAY*/
#define BSP_DIS_CLK     23  //MOSI
#define BSP_DIS_DIO     19 //MISO

/*ADC input for battery Monitoring*/
#define BSP_WDT             34
#define WDT_TIMEOUT         60


class cBsp
{
    public:
        bool m_bIsRtcSynced;
        float pcbMake;
  
        /*Construct*/
        cBsp(void);
        /*Destruct*/
        ~cBsp(void);
        /*Functions*/
        void setPcbMake(float);
        void OnOffRelay(uint8_t relayNo,uint8_t state);
        void gpioInitialization(void);
        void i2cInitialization(void);
        // void RTCInit(PCF85063A* );
        void spiInitialization(void);
        void wdtPinToggle(void);
        void indLedToggle(void);
        void indLedOff(void);
        uint8_t getButtonEvent(void);
        int syncRTCTime(cPCF85063A*, time_t, time_t);
        time_t ConvertEpoch(cPCF85063A* LoclRTC);
        void ioPinWrite(uint8_t , bool );
        uint8_t ioPinRead(uint8_t pin);
        void wdtInit(void);
        void wdtAdd(TaskHandle_t );
        void wdtfeed(void);
        uint8_t getBoardPowerStatus(void);
        void hooterOn(void);
        void hooterOff(void);
};

#endif
